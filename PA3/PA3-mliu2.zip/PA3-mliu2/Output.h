/*
=======================================================================================================
Name		: Output.h
Author		: Yixue Wang, Mingquan Liu
Version		: 1.1
Copyright	:
Description	: The hearder file for Output.c
=======================================================================================================
 */

#ifndef OUTPUT_H_
#define OUTPUT_H_

FILE* printTree(Node *p, FILE *file_A, int *distinct, int *total);

#endif
