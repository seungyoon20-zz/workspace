/*
=======================================================================================================
Name		: Input.h
Author		: Yixue Wang, Mingquan Liu
Version		: 1.1
Copyright	:
Description	: The header file for Input.c
=======================================================================================================
 */

#ifndef INPUT_H_
#define INPUT_H_

Node* parseFile(FILE *input, Node *p, Node *parent);

#endif
