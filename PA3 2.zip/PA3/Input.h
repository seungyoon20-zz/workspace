//////////PA3///////////ywang20/////////////////

#ifndef INPUT_H_
#define INPUT_H_

Node* parseFile(FILE *input, Node *p, Node *parent);

#endif
