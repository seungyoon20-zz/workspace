//////////PA3///////////ywang20/////////////////

#ifndef OUTPUT_H_
#define OUTPUT_H_

FILE* printTree(Node *p, FILE *file_A, int *distinct, int *total);

#endif
