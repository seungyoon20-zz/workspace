//////////PA3///////////ywang20/////////////////
#include <stdio.h>
#include "Tree.h"
#include <stdlib.h>
#include "Input.h"
#include <ctype.h>
#include <string.h>
//#include <string.h>

//int SINGLE_QUOTE = '\'';

Node* parseFile(FILE *fp, Node *p, Node *parent){
    char temp[50];
    int c;
    int count;
    char *word;


    count = 0;
    while ((c = fgetc(fp)) != EOF) {
        if( c == 39){
            temp[count] = c;
            count++;
            //printf("%c\n", c);
            continue;
        }
        
    	if(isalpha(c) ){				//if word chuu
    		temp[count] = tolower(c);
    		count++;
            //printf("%c\n", c);
    		continue;
    	}

    	if (count == 0){						//if blank
    		continue;
    	}

    	temp[count] = 0;
    	word = malloc(count * sizeof(char));
        word = strcpy(word, temp);
    	p = addItem(p, word, parent);
        //p = addItem(p, "word", parent);
    	//printf("%s\n", strcpy(word, temp));
    	free(word);
    	count = 0;
    }
    return p;

}

