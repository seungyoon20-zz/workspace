#include "Organism.h"
#include "Ant.h"
#include "Doodle.h"
#include <iostream>
#include <cstdlib>

using std::cout;

void printBoard(int row, int col, Organism** B[]){
    
    for(int r = 0; r < row; r++){
        for(int c = 0; c < col; c++){
            if(B[r][c]){
                B[r][c]->print();
            }
            else{
                cout << "-";
            }
        }
        cout << "\n";
    }
}


int main(int argc, char* argv[]){
    Organism*** Board;
    int seed;
    

    seed = time(0);
    srand(seed);
    Board = new Organism**[3];
    Board[0] = new Organism*[3];
    Board[1] = new Organism*[3];
    Board[2] = new Organism*[3];
    
    Board[2][0] = new Ant(2, 0);
    Board[2][1] = new Doodle(2,1);
    printBoard(3, 3, Board);
    cout << "\n";
    Board = Board[2][1]->breed(3, Board);
    printBoard(3, 3, Board);

    cout << "\n";
    Board = Board[2][1]->starvation(3, Board);
    printBoard(3, 3, Board);


    delete[] Board[0];
    delete[] Board[1];
    delete[] Board[2];
    
    delete[] Board;
    Board = 0;
    return 0;
}

