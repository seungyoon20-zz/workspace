
#include "Teller.h"
#include "Event.h"
#include "Customer.h"
#include <iostream>
#include <sstream>
#include <string>
using std::cin;
using std::cout;
using std::endl;
/*This is the formal bank model which will produce the bank model based on the command line input.
 *
 */
int timeRange,avgTime,numCus,numTell,cTime,serveC;
float avgTimeM;
Event *lastEvent;
int getShortestWaitingLine(Event* w[],int length);
int main (int argc, char* argv[]){
//Teller *a = new Teller();
//a->setServeTime(60,200);
//cout << a->getServeTime();
	Event *head = 0;						// head is for storing the head event
	cTime =0;
	serveC=0;
	srand(1234567890);
	Event *eventList = 0;
	if(argc<4) {
		cout << "You have wrong command line input";
		//exit(-1);
	}
	 numCus = atoi(argv[1]);
	 numTell = atoi(argv[2]);
	 timeRange =atoi(argv[3]);
	 avgTimeM = atof(argv[4]);

	timeRange = timeRange*60;		//Change the Time range from minutes to seconds.
	avgTime =(int)(avgTimeM*60);   	//change avgTime from float minutes to int seconds
	cout <<avgTime <<endl <<timeRange<<endl;
	   Event *waitingList[numTell]; // Creating
	   int TellerData[numTell][2];		// Create an array of integer to record the teller's data for serving and idling. TellerData[][0] for serving time and TellerData[][1] for idle time
	   int customerData[numCus+1][2];
									//Setting up the bank model right now.

	//Teller* teller = new Teller();
	for(int i=1;i<numCus+1;i++){					// Build up the event list
		Customer *a = new Customer();
		a->setTeller(-i);
		a->Action(timeRange,false,0);
		if(head==0) head=a;
		else
			head->addEvent(a);
		head =a->getFirstEvent();
		customerData[i][0]=0;
		customerData[i][1]=0;
	}
	Event*a =head;
	cout<< "Length"<<head->getLength();
	for(int i=0;i<numCus;i++){
		cout<<a->getExTime()<<endl;
		a=a->getNextEvent();
	}

   for(int i=0;i<numTell;i++){					// Add teller event to the beginning of the
	   waitingList[i]=0;
	   Teller *a = new Teller();
	   a->setExTime(0);
	   a->setTeller(i);
	   head->addEvent(a);
	   head = a->getFirstEvent();
	   TellerData[i][0]=0;
	   TellerData[i][1]=0;
   }
//   cout<<"Length:"<<head->getLength()<<endl;
   cout<<"Length:"<<head->isTeller()<<endl;
   cout<<head->getLength()<<endl;

   while(head!=0&&cTime<timeRange){								// running the event queue
	   cTime = head->getExTime();				// Update the current time
	   if(head->isTeller()>=0){

		   int num = head->isTeller();			// record the teller number
//		   if(head->isServ()) cout<<"Teller "<<num<<" service ends at "<<cTime<<endl;
//		   if(!(head->isServ())) cout<<"Teller "<<num<<" idle ends at "<<cTime<<endl;
//		   TellerData[num][0] = TellerData[num][0]+head->getServeTime();		// update the teller data.
//		   TellerData[num][1] = TellerData[num][1]+head->getIdleTime();		// update the teller data.

		   if(waitingList[num]!=0){				// The case for when there is someone in front of you
			   Teller *t = new Teller();
			   Customer *c = new Customer();
			   t->setTeller(num);
//			   int cusNum = waitingList[num]->isTeller();
//			   c->setTeller(cusNum);
			   t->Action(avgTime,true,cTime);	// set up the service time
			   int serveT = t->getServeTime();
//			   int wTime = cTime-waitingList[num]->getExTime();
			   c->Action(serveT,true,cTime);
			   head->addEvent(t);
			   cout << "Teller "<<num<<" gets a service at "<<cTime<<endl;
			   head->addEvent(c);
			   waitingList[num]= waitingList[num]->dequeue();     // move the waiting list
			   serveC++;
			   TellerData[num][0] = TellerData[num][0]+serveT;		// update the teller data.
//			   customerData[-cusNum][0]=customerData[-cusNum][0]+serveT;
//			   customerData[-cusNum][1]=customerData[-cusNum][1]+wTime;

		   }
		   else									// for the shortest line of others
		   {
			   int tNum = getShortestWaitingLine(waitingList,numTell);
			   if(waitingList[tNum]==0){			//The case for the idle time
				  Teller* t = new Teller();
				  t->setTeller(num);
				  t->Action(0,false,cTime);
				  int idleTime = t->getIdleTime();
				  TellerData[num][1] = TellerData[num][1]+t->getIdleTime();		// update the teller data.
				  head->addEvent(t);
				  //cout << cTime<<" Idle "<<idleTime<<endl;
			   }
			   else												// for the case of getting from the shortest line.
			   {
				   Teller *t = new Teller();
				   Customer *c = new Customer();
//				   int cusNum = waitingList[num]->isTeller();
//				   c->setTeller(cusNum);
				   t->setTeller(num);
				   t->Action(avgTime,true,cTime);	// set up the service time
				   int serveT = t->getServeTime();
//				   int wTime = cTime-waitingList[tNum]->getExTime();
				   c->Action(serveT,true,cTime);
				   head->addEvent(t);
				   head->addEvent(c);
				   waitingList[tNum]=waitingList[tNum]->dequeue();
				   serveC++;
				   TellerData[num][0] = TellerData[num][0]+serveT;		// update the teller data.
//				   customerData[-cusNum][0]=customerData[-cusNum][0]+serveT;
//				   customerData[-cusNum][1]=customerData[-cusNum][1]+wTime;
			   }
		   }
	   }
	   else
	   {
		   if(!head->isServ())
		   {
//		   cout<<"Customer comes at "<<head->isTeller()<<endl;
		   cout<<"Customer comes at "<<cTime<<endl;
		   int tNum = getShortestWaitingLine(waitingList,numTell);
		   Event* c = new Event();
		   c->setExTime(cTime);
		   	   if(waitingList[tNum]==0)
		   	   {
			   waitingList[tNum]= c;
		   	   }
		   	   else
		   		   waitingList[tNum]->addEvent(c);
		   }
		   else
		   {
			   //serveC++;
		   }
	   }

	   head = head->dequeue();
   }
   for(int i=0;i<numTell;i++){
	   cout<< "The Teller "<<i<<" serves "<<TellerData[i][0]<<" seconds and ildes " <<TellerData[i][1]<<endl;
   }
//   for(int i=0;i<numCus;i++){
//	   cout<< "The Customer "<<i<<" waits "<<customerData[i][0]<<" seconds and ildes " <<customerData[i][1]<<endl;
//   }
	cout << serveC;


}

int getShortestWaitingLine(Event* w[],int length){	//find the shortest line in the waiting list
	//Event** a = w;
	  // cout<<"findShortest"<<endl;
	 int l=0;
	int tNum =0;
	for(int i=0;i<length;i++){
		int len=0;
		if(w[i]!=0)
		{
		len =w[i]->getLength();
		}


		if(len<l){
			l =len;
		     tNum =i;
		}
	}
	return tNum;
}

