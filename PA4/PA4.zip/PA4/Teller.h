/*
 * Teller.h
 *
 *  Created on: Feb 11, 2017
 *      Author: mingquan
 */
#include "Event.h"
#include <cstdlib>
#ifndef TELLER_H_
#define TELLER_H_

class Teller : public Event{
public:
	Teller();
	virtual ~Teller();
	void setIdleTime(int cTime);
	void setServeTime(int avgSTime,int cTime);
	int  getServeTime();
	int  getIdleTime();
	void Action (int avgTime,bool isServ,int cTime);
	int isTeller();
	void setTeller(int n);
	bool isServ();

private:
	int idleTime,serveTime,tellerNum;
	bool isService;
};

#endif /* TELLER_H_ */
